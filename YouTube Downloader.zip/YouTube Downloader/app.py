from flask import Flask, render_template, request, send_from_directory, jsonify
from pytube import Playlist, YouTube
import os

app = Flask(__name__)
DOWNLOAD_FOLDER = 'downloads'
app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_FOLDER

if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_playlist', methods=['POST'])
def get_playlist():
    url = request.form['url']
    playlist = Playlist(url)
    videos = [{'title': video.title, 'thumbnail': video.thumbnail_url, 'url': video.watch_url} for video in playlist.videos]
    return jsonify(videos)

@app.route('/download', methods=['POST'])
def download():
    video_urls = request.json['urls']
    format = request.json['format']
    for url in video_urls:
        yt = YouTube(url)
        if format == 'video':
            stream = yt.streams.get_highest_resolution()
        else:
            stream = yt.streams.filter(only_audio=True).first()
        stream.download(output_path=app.config['DOWNLOAD_FOLDER'])
    return jsonify({'status': 'success'})

@app.route('/downloads/<filename>')
def download_file(filename):
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)
